/* Biology Career Compass — app logic. No libraries, no build step. */

/* ---- Site settings: edit these two lines ---- */
const SITE = {
  channelUrl: "",   // e.g. "https://www.youtube.com/@yourchannel" — shows the "Watch on YouTube" button
  baseUrl: "https://saimacyto.github.io/Career-website-/"       // e.g. "https://yourname.github.io/biology-career-compass/" — used for shareable career links
};

(function () {
  const careers = window.CAREERS;
  const CATS = window.CATEGORIES;
  const CAT_ORDER = ["lab", "rehab", "clinical", "research"];
  const byId = Object.fromEntries(careers.map(c => [c.id, c]));

  const SHORT = {
    mls: "MLS", mlt: "MLT", cytotech: "Cytotech", histotech: "Histotech", radtech: "Rad tech",
    sonography: "Sonographer", nucmed: "Nuc med", pt: "Physical therapist", pta: "PT assistant",
    ot: "Occupational therapist", ota: "OT assistant", slp: "Speech pathologist", rt: "Respiratory therapist",
    at: "Athletic trainer", pa: "PA", rn: "Nurse (RN)", pharmacist: "Pharmacist", dentist: "Dentist",
    physician: "Physician", gc: "Genetic counselor", mph: "Public health", dietitian: "Dietitian",
    researchtech: "Research tech", crc: "Research coordinator", regulatory: "Regulatory", bioinformatics: "Bioinformatics",
    medscientist: "PhD scientist"
  };

  const $ = sel => document.querySelector(sel);
  const esc = s => String(s).replace(/[&<>"']/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
  const yrsShort = c => (c.years >= 11 ? "11+ yrs" : c.years + " yrs");

  /* ---------------- hero category tiles ---------------- */
  $("#hero-cats").innerHTML = CAT_ORDER.map(k => {
    const n = careers.filter(c => c.cat === k).length;
    return `<li><a href="#explore" data-cat="${k}" data-jump="${k}">
      <em>${n} careers</em><strong>${esc(CATS[k].label)}</strong><span>${esc(CATS[k].blurb)}</span></a></li>`;
  }).join("");
  document.querySelectorAll("[data-jump]").forEach(a => a.addEventListener("click", () => setCat(a.dataset.jump)));

  /* ---------------- ruler / map ---------------- */
  const MAX_Y = 12;
  function renderRuler() {
    const ruler = $("#ruler");
    ruler.innerHTML = CAT_ORDER.map(k => `
      <div class="r-row" data-cat="${k}" role="listitem">
        <div class="r-label">${esc(CATS[k].label)}</div>
        <div class="r-track" data-track="${k}"></div>
      </div>`).join("") + `
      <div class="r-axis"><div class="r-axis-label">years after<br>high school</div>
        <div class="r-ticks">${[0, 2, 4, 6, 8, 10, 12].map(t =>
          `<span class="r-tick" style="left:${(t / MAX_Y) * 100}%">${t}${t === 12 ? "+" : ""}</span>`).join("")}</div>
      </div>`;
    layoutRuler();
  }
  function layoutRuler() {
    CAT_ORDER.forEach(k => {
      const track = document.querySelector(`[data-track="${k}"]`);
      const W = track.clientWidth;
      const items = careers.filter(c => c.cat === k).sort((a, b) => a.years - b.years);
      const lanes = []; // right edge (px) of last item in each lane
      let html = "";
      items.forEach(c => {
        const label = SHORT[c.id] || c.name;
        const w = label.length * 7 + 34;
        const x = (Math.min(c.years, MAX_Y) / MAX_Y) * W;
        const left = x - w / 2;
        let lane = lanes.findIndex(r => r + 6 < left);
        if (lane === -1) { lane = lanes.length; lanes.push(0); }
        lanes[lane] = x + w / 2;
        html += `<button type="button" class="r-dot" style="position:absolute;left:${x}px;top:${10 + lane * 32}px;transform:translateX(-50%)"
          data-open="${c.id}" title="${esc(c.name)} · ${esc(c.yearsLabel)}">${esc(label)}</button>`;
      });
      track.innerHTML = html;
      track.style.minHeight = (20 + lanes.length * 32) + "px";
    });
  }
  renderRuler();
  let rt;
  window.addEventListener("resize", () => { clearTimeout(rt); rt = setTimeout(layoutRuler, 120); });

  /* ---------------- explorer ---------------- */
  const state = { q: "", cat: "all", sort: "cat" };
  let visibleOrder = careers.map(c => c.id);

  $("#filters").innerHTML =
    `<button type="button" class="chip" data-filter="all" aria-pressed="true">All</button>` +
    CAT_ORDER.map(k => `<button type="button" class="chip" data-filter="${k}" data-cat="${k}" aria-pressed="false">${esc(CATS[k].label)}</button>`).join("");
  $("#filters").addEventListener("click", e => {
    const b = e.target.closest("[data-filter]");
    if (b) setCat(b.dataset.filter);
  });
  $("#search").addEventListener("input", e => { state.q = e.target.value.trim().toLowerCase(); renderGrid(); });
  $("#sort").addEventListener("change", e => { state.sort = e.target.value; renderGrid(); });

  function setCat(cat) {
    state.cat = cat;
    document.querySelectorAll("#filters .chip").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.filter === cat)));
    renderGrid();
  }

  function matches(c) {
    if (state.cat !== "all" && c.cat !== state.cat) return false;
    if (!state.q) return true;
    const hay = [c.name, c.credential, c.tagline, c.day, c.degree, c.exam, SHORT[c.id], CATS[c.cat].label, ...c.tags].join(" ").toLowerCase();
    return state.q.split(/\s+/).every(w => hay.includes(w));
  }

  function card(c) {
    return `<button type="button" class="card" data-cat="${c.cat}" data-open="${c.id}">
      <span class="card-top"><span class="cred">${esc(c.credential)}</span><span class="yrs">${yrsShort(c)}</span></span>
      <span class="card-title">${esc(c.name)}</span>
      <span class="card-text">${esc(c.tagline)}</span>
      <span class="card-foot"><span class="deg">${esc(c.degree)}</span><span class="more">Details →</span></span>
    </button>`;
  }

  function renderGrid() {
    let list = careers.filter(matches);
    if (state.sort === "years") list.sort((a, b) => a.years - b.years || a.name.localeCompare(b.name));
    else if (state.sort === "name") list.sort((a, b) => a.name.localeCompare(b.name));
    else list.sort((a, b) => CAT_ORDER.indexOf(a.cat) - CAT_ORDER.indexOf(b.cat) || a.years - b.years);
    visibleOrder = list.map(c => c.id);

    $("#count").textContent = `Showing ${list.length} of ${careers.length} careers`;
    if (!list.length) {
      $("#grid").innerHTML = `<div class="empty">No careers match “${esc(state.q)}”. Try a broader word like “lab”, “patients”, or “master's”.</div>`;
      return;
    }
    if (state.sort === "cat") {
      $("#grid").innerHTML = CAT_ORDER.map(k => {
        const g = list.filter(c => c.cat === k);
        if (!g.length) return "";
        return `<div class="group-title" data-cat="${k}"><h3>${esc(CATS[k].label)}</h3><span>${esc(CATS[k].blurb)}</span></div>` + g.map(card).join("");
      }).join("");
    } else {
      $("#grid").innerHTML = list.map(card).join("");
    }
  }
  renderGrid();

  /* ---------------- detail dialog ---------------- */
  const dlg = $("#detail");
  let currentId = null;

  function shareUrl(id) {
    const base = SITE.baseUrl || (location.origin + location.pathname);
    return base + "#career-" + id;
  }

  function openCareer(id, push = true) {
    const c = byId[id];
    if (!c) return;
    currentId = id;
    const order = visibleOrder.includes(id) ? visibleOrder : careers.map(x => x.id);
    const i = order.indexOf(id);
    const prev = byId[order[(i - 1 + order.length) % order.length]];
    const next = byId[order[(i + 1) % order.length]];

    const video = c.video
      ? `<div class="video-box"><p><strong>Watch the episode</strong> on this career.</p><a class="btn btn-primary" href="${esc(c.video)}" target="_blank" rel="noopener">Play video</a></div>`
      : `<div class="video-box"><p><strong>Video episode coming soon.</strong> This career is on the series list.</p></div>`;

    const links = [
      c.accreditor ? { label: `Find accredited programs (${c.accreditor.name})`, url: c.accreditor.url } : null,
      ...c.links,
      { label: "Pay & job outlook (BLS)", url: c.bls }
    ].filter(Boolean);

    $("#detail-body").innerHTML = `
      <div class="d-head" data-cat="${c.cat}">
        <div class="d-top"><span class="d-cat">${esc(CATS[c.cat].label)}</span>
          <button type="button" class="close" data-close aria-label="Close">×</button></div>
        <h2 id="d-name">${esc(c.name)}</h2>
        <p class="d-tag">${esc(c.tagline)}</p>
      </div>
      <dl class="facts" data-cat="${c.cat}">
        <div class="fact"><dt>Credential</dt><dd>${esc(c.credential)}</dd></div>
        <div class="fact"><dt>Degree</dt><dd>${esc(c.degree)}</dd></div>
        <div class="fact"><dt>Time after high school</dt><dd>${esc(c.yearsLabel)}</dd></div>
        <div class="fact"><dt>Exam</dt><dd>${esc(c.exam)}</dd></div>
      </dl>
      <div class="d-sec"><h3>What the work looks like</h3><p>${esc(c.day)}</p></div>
      <div class="d-sec" data-cat="${c.cat}"><h3>Your route in</h3>
        <ol class="steps">${c.route.map(s => `<li><span>${esc(s)}</span></li>`).join("")}</ol></div>
      <div class="d-sec" data-cat="${c.cat}"><h3>Links</h3>
        <div class="links">${links.map(l => `<a href="${esc(l.url)}" target="_blank" rel="noopener">${esc(l.label)} ↗</a>`).join("")}</div></div>
      ${video}
      <div class="share"><span>Link to this career:</span><code id="share-url">${esc(shareUrl(c.id))}</code>
        <button type="button" id="copy-link">Copy</button></div>
      <div class="d-nav">
        <button type="button" data-open="${prev.id}">← ${esc(prev.name)}</button>
        <button type="button" data-open="${next.id}">${esc(next.name)} →</button>
      </div>`;

    if (!dlg.open) dlg.showModal();
    dlg.scrollTop = 0;
    $("#detail-body").scrollTop = 0;
    if (push && location.hash !== "#career-" + id) {
      try { history.replaceState(null, "", "#career-" + id); } catch (e) { /* frame may block this */ }
    }
  }

  function closeCareer() {
    if (dlg.open) dlg.close();
  }
  dlg.addEventListener("close", () => {
    currentId = null;
    if (location.hash.startsWith("#career-")) {
      try { history.replaceState(null, "", location.pathname + location.search); } catch (e) { }
    }
  });
  dlg.addEventListener("click", e => {
    if (e.target === dlg) closeCareer(); // backdrop
    if (e.target.closest("[data-close]")) closeCareer();
    if (e.target.id === "copy-link") {
      const text = $("#share-url").textContent;
      const btn = e.target;
      const selectIt = () => { const r = document.createRange(); r.selectNodeContents($("#share-url")); const s = getSelection(); s.removeAllRanges(); s.addRange(r); btn.textContent = "Selected, press Ctrl+C"; };
      try {
        navigator.clipboard.writeText(text).then(() => { btn.textContent = "Copied"; }, selectIt);
      } catch (err) { selectIt(); }
    }
  });

  document.addEventListener("click", e => {
    const t = e.target.closest("[data-open]");
    if (t) { e.preventDefault(); openCareer(t.dataset.open); }
  });

  function fromHash() {
    const m = location.hash.match(/^#career-([a-z0-9]+)$/);
    if (m && byId[m[1]]) openCareer(m[1], false);
  }
  window.addEventListener("hashchange", fromHash);
  fromHash();

  /* ---------------- biology-grad fast routes ---------------- */
  const ROUTES = [
    { time: "About 12 months", title: "Post-bacc MLS certificate", text: "Hospital- and university-based programs take biology graduates straight into the clinical lab, then the ASCP MLS exam.", ids: ["mls"] },
    { time: "12–24 months", title: "Cytotechnology program", text: "Certificate or master's programs for science graduates who like microscope diagnosis.", ids: ["cytotech"] },
    { time: "12–18 months", title: "Accelerated BSN", text: "Second-degree nursing programs build on your first bachelor's, then the NCLEX-RN.", ids: ["rn"] },
    { time: "12–18 months", title: "Imaging certificates", text: "Sonography and nuclear medicine offer certificate tracks for people who already hold a degree.", ids: ["sonography", "nucmed"] },
    { time: "Start now", title: "Research and trials jobs", text: "Research tech and clinical research coordinator roles hire biology graduates directly and pay while you decide.", ids: ["researchtech", "crc"] },
    { time: "2–3 years", title: "Graduate health programs", text: "Your prerequisites are mostly done. Add observation or patient-care hours and apply to PA, OT, PT, or genetic counseling.", ids: ["pa", "ot", "pt", "gc"] }
  ];
  $("#routes").innerHTML = ROUTES.map(r => `
    <div class="route"><span class="time">${esc(r.time)}</span><h3>${esc(r.title)}</h3><p>${esc(r.text)}</p>
      <div class="links">${r.ids.map(id => `<button type="button" data-open="${id}">${esc(SHORT[id])} →</button>`).join("")}</div>
    </div>`).join("");

  /* ---------------- quiz ---------------- */
  const QUESTIONS = [
    { id: "q1", text: "How much time with patients do you want?", weight: 1.5, opts: [
      ["patients", "Most of my day"], ["some-patients", "Some, not all day"], ["behind", "Behind the scenes"]] },
    { id: "q2", text: "Which sounds most like fun?", weight: 2, opts: [
      ["lab", "Microscopes and specimens"], ["movement", "Helping bodies move and heal"], ["tech", "Running imaging or life-support machines"],
      ["data", "Data, documents, and details"], ["talk", "Talking, teaching, counseling"]] },
    { id: "q3", text: "How many years of school after high school are you ready for?", years: true, opts: [
      ["2", "About 2"], ["4", "About 4"], ["7", "6 to 7"], ["99", "As long as it takes"]] },
    { id: "q4", text: "What pace do you like?", weight: 1, opts: [
      ["fast", "Fast, high stakes"], ["steady", "Steady and predictable"]] },
    { id: "q5", text: "Where would you rather work?", weight: 1, opts: [
      ["hospital", "Hospital"], ["community", "Clinic, school, or sports"], ["industry", "Lab, office, or company"]] }
  ];
  const TAG_WORDS = {
    patients: "lots of patient time", "some-patients": "some patient contact", behind: "behind-the-scenes work",
    lab: "lab and microscope work", movement: "hands-on rehab", tech: "technology and equipment", data: "data and detail",
    talk: "talking and teaching", fast: "a fast pace", steady: "a steady pace", hospital: "hospital setting",
    community: "clinic or community setting", industry: "lab or industry setting"
  };

  $("#quiz-form").innerHTML = QUESTIONS.map((q, qi) => `
    <fieldset class="q"><legend><span class="q-num">${qi + 1}/5</span>${esc(q.text)}</legend>
      <div class="opts">${q.opts.map(([v, label], oi) => `
        <label class="opt"><input type="radio" id="${q.id}-${oi}" name="${q.id}" value="${v}" ${oi === 0 ? "required" : ""}><span>${esc(label)}</span></label>`).join("")}
      </div></fieldset>`).join("") + `
    <div class="quiz-actions"><button class="btn btn-primary" type="submit">Show my matches</button>
      <button class="btn btn-ghost" type="reset">Start over</button></div>`;

  $("#quiz-form").addEventListener("reset", () => { $("#quiz-results").innerHTML = ""; });
  $("#quiz-form").addEventListener("submit", e => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const maxYears = Number(fd.get("q3"));
    const scored = careers.map(c => {
      let s = 0; const why = [];
      QUESTIONS.forEach(q => {
        if (q.years) return;
        const v = fd.get(q.id);
        if (c.tags.includes(v)) { s += q.weight; why.push(TAG_WORDS[v]); }
        else if (q.id === "q1" && v === "some-patients" && c.tags.includes("patients")) s += 0.5;
      });
      if (c.years <= maxYears) { s += 1.5; why.push(`about ${yrsShort(c)} of school`); }
      else s -= (c.years - maxYears) * 0.6;
      return { c, s, why };
    }).sort((a, b) => b.s - a.s || a.c.years - b.c.years).slice(0, 3);

    $("#quiz-results").innerHTML = `<h3>Your top three to research</h3>` + scored.map((r, i) => `
      <div class="result" data-cat="${r.c.cat}">
        <span class="rank">${i + 1}</span>
        <div><h4>${esc(r.c.name)}</h4><p>Matches: ${esc(r.why.join(", ") || "a partial fit")}.</p></div>
        <button type="button" class="btn btn-ghost" data-open="${r.c.id}">See the route</button>
      </div>`).join("");
    $("#quiz-results").scrollIntoView({ behavior: "smooth", block: "nearest" });
  });

  /* ---------------- resources ---------------- */
  const APPS = [
    ["PTCAS", "Physical therapy", "https://www.ptcas.org"],
    ["OTCAS", "Occupational therapy", "https://otcas.liaisoncas.com"],
    ["CASPA", "Physician assistant", "https://caspa.liaisoncas.com"],
    ["CSDCAS", "Speech-language pathology", "https://csdcas.liaisoncas.com"],
    ["ATCAS", "Athletic training", "https://atcas.liaisoncas.com"],
    ["NursingCAS", "Nursing", "https://www.nursingcas.org"],
    ["PharmCAS", "Pharmacy", "https://www.pharmcas.org"],
    ["AMCAS", "MD medical school", "https://www.aamc.org"],
    ["AACOMAS", "DO medical school", "https://aacomas.liaisoncas.com"],
    ["ADEA AADSAS", "Dental school", "https://www.adea.org/godental"],
    ["SOPHAS", "Public health", "https://sophas.org"]
  ];
  $("#apps").innerHTML = APPS.map(([n, f, u]) => `<li><a href="${u}" target="_blank" rel="noopener">${n}</a><small>${f}</small></li>`).join("");

  const seen = new Map();
  careers.forEach(c => {
    if (!c.accreditor) return;
    const key = c.accreditor.name;
    if (!seen.has(key)) seen.set(key, { url: c.accreditor.url, fields: [] });
    const f = SHORT[c.id];
    if (!seen.get(key).fields.includes(f)) seen.get(key).fields.push(f);
  });
  $("#accred").innerHTML = [...seen].map(([n, v]) =>
    `<li><a href="${v.url}" target="_blank" rel="noopener">${esc(n)}</a><small>${esc(v.fields.join(", "))}</small></li>`).join("");

  /* ---------------- channel link ---------------- */
  if (SITE.channelUrl) { const a = $("#channel-link"); a.href = SITE.channelUrl; a.hidden = false; }
})();
