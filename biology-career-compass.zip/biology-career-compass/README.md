# Biology Career Compass

A free, static website that helps biology students and graduates in the US compare 27 health and science careers: medical laboratory science, cytotechnology, histotechnology, imaging, physical and occupational therapy, speech pathology, respiratory therapy, PA, nursing, pharmacy, dentistry, medicine, genetic counseling, public health, dietetics, and research/industry roles.

Companion site for the **Smart Simplicity System** video series.

## What's on the site

- **Map**: every career plotted by years of school after high school
- **Explore**: searchable, filterable cards, each opening a full detail view (credential, degree, exam, route in, accreditor, professional society, BLS pay link, video slot)
- **Already have a biology degree?**: faster routes such as post-bacc MLS, accelerated BSN, and imaging certificates
- **Quiz**: five questions that suggest three careers to research
- **Resources**: centralized application services, accreditors, and outlook data

No frameworks, no build step. Plain HTML, CSS, and JavaScript.

```
index.html        page structure
css/styles.css    all styling (light and dark mode)
js/careers.js     career content: edit this to add or change careers
js/app.js         site behavior, plus SITE settings at the top
.nojekyll         tells GitHub Pages to serve files as-is
```

## Publish on GitHub Pages

1. Create a new repository on GitHub, for example `biology-career-compass` (Public).
2. Upload every file in this folder (drag and drop into **Add file → Upload files** works), keeping the `css` and `js` folders.
3. Go to **Settings → Pages**. Under **Build and deployment**, choose **Deploy from a branch**, branch `main`, folder `/ (root)`, and save.
4. After a minute or two the site is live at `https://saimacyto.github.io/Career-website-/`.

Or from a terminal:

```bash
cd biology-career-compass
git init
git add .
git commit -m "Launch Biology Career Compass"
git branch -M main
git remote add origin https://github.com/saimacyto/Career-website-.git
git push -u origin main
```

## Settings to fill in

At the top of `js/app.js`:

```js
const SITE = {
  channelUrl: "https://www.youtube.com/@yourchannel",
  baseUrl: "https://saimacyto.github.io/Career-website-/"
};
```

- `channelUrl` shows the **Watch on YouTube** button.
- `baseUrl` makes the "Link to this career" text show your real site address.

## Link an episode to a career

In `js/careers.js`, find the career and paste the video URL:

```js
id: "mls",
...
video: "https://www.youtube.com/watch?v=XXXXXXXX"
```

The career page then shows a **Play video** button instead of "coming soon".

Every career has its own shareable link for video descriptions:

| Career | Link ending |
|---|---|
| Medical Laboratory Scientist | `#career-mls` |
| Physical Therapist | `#career-pt` |
| Occupational Therapist | `#career-ot` |
| Physician Assistant | `#career-pa` |
| Cytotechnologist | `#career-cytotech` |

The pattern is always `#career-<id>`, using the `id` in `careers.js`.

## Add a career

Copy any object in `js/careers.js`, give it a new unique `id`, and fill in the fields. Add a short label for the map in the `SHORT` list near the top of `js/app.js`. The comment block at the top of `careers.js` explains every field, including the quiz `tags`.

## Keeping content accurate

Requirements, exams, and program formats change. Before each video, check the accreditor and certification board linked on that career's page. Salary figures are deliberately not copied into the site; each career links to its Bureau of Labor Statistics page, which updates yearly. Content last reviewed September 2026.
